<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ExpenseCategory extends Model
{
    use HasFactory;

    protected $fillable = [
        'name', 
        'description', 
        'is_active'
    ];

    // Ek category mein bohot saare expenses ho sakte hain
    public function expenses()
    {
        return $this->hasMany(Expense::class);
    }
}